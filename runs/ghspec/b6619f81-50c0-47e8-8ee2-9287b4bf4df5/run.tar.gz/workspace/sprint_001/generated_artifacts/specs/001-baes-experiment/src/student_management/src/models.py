```
Flask==2.2.2
SQLAlchemy==1.4.39
pytest==7.1.2
```