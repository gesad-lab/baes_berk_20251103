```
Flask>=2.0
SQLAlchemy>=1.4
Flask-Migrate>=3.1
```