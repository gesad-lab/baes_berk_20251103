# Creating .env.example with necessary configurations

DATABASE_URL=sqlite:///students.db
SECRET_KEY=your_secret_key
DEBUG=True

# Other potential environment variables as needed
# PORT=8000
# TIMEOUT=30
