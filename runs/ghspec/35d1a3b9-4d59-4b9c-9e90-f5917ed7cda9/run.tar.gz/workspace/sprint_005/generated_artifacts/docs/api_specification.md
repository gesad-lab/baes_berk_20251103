fastapi
uvicorn
sqlalchemy
alembic
pytest
