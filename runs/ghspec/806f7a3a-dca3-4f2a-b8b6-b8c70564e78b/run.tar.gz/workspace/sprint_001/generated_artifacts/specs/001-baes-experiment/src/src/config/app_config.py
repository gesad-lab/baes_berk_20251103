# requirements.txt

Flask==2.0.2
Flask-SQLAlchemy==2.5.1
marshmallow==3.13.0
pytest==6.2.5
pytest-flask==1.2.0
flask-marshmallow==0.14.0
sqlite3
