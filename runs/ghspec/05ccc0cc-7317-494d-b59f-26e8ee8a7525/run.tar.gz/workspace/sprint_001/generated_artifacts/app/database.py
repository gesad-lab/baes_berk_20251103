```python
# app/__init__.py

# This file indicates that the app directory is a Python package.
```