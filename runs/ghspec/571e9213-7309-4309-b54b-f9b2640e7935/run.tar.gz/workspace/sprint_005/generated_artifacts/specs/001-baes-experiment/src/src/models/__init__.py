```python
from .student import Student
from .course import Course
from .teacher import Teacher  # New Teacher model imported here
```