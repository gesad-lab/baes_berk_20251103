```python
# src/models/__init__.py

# Existing import statements
from .student import Student
from .course import Course  # Importing Course for model integration
```