```python
# src/models/__init__.py

# Existing import statements
from .student import Student
from .course import Course
from .student_course import StudentCourse  # New StudentCourse import
```