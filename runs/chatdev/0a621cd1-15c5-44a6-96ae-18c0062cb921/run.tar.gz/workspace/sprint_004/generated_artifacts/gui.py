'''
Main GUI for the Student Management application.
'''
/student_app
    ├── main.py
    ├── models.py
    ├── database.py
    ├── routes.py
    └── gui.py