'''
Graphical User Interface for the student application.
'''
# (Assuming there are GUI components here; no changes needed for this file)