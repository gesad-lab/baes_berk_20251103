'''
Graphical User Interface for the Student application.
'''
# No changes needed in gui.py for this task.