'''
Command to create a new migration script.
'''
alembic revision --autogenerate -m "Add Teacher table and update Course table"