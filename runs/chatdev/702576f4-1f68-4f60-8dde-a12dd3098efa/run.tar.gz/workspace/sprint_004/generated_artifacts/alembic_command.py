'''
Command to create a new migration script.
'''
alembic revision --autogenerate -m "Add student_courses association table"