'''
Main GUI file for the student application.
'''
# This file can be expanded for GUI functionalities if needed.