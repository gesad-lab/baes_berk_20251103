'''
Command to run the FastAPI application.
'''
uvicorn main:app --reload