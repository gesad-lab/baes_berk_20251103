/student_app
    ├── main.py
    ├── models.py
    ├── database.py
    └── gui.py