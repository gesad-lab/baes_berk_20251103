'''
Graphical User Interface for the Student Management application.
'''
# This file is not modified as per the current task requirements.