'''
Run Alembic migrations.
'''
alembic upgrade head