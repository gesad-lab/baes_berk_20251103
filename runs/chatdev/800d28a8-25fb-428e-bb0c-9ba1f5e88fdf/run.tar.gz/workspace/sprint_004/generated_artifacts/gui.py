'''
Main GUI for the Student Management application.
'''
# Note: The content of this file is not provided in the original code. 
# Assuming it contains GUI components for managing students and courses.