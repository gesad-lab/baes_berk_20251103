/student_app
    ├── main.py
    ├── models.py
    ├── database.py
    ├── schemas.py
    ├── api.py
    └── gui.py