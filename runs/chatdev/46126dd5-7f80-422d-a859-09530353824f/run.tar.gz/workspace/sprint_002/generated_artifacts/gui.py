'''
Main GUI file for the student application.
'''
# GUI implementation would go here