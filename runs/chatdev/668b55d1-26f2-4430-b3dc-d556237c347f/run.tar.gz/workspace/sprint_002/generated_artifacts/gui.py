'''
Graphical User Interface for the student application.
'''
# No changes were made to this file as it was not provided in the original request.