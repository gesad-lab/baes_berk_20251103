'''
Graphical User Interface for the Student application.
'''
# GUI code would go here (not specified in the original request)