# Run Summary

**Run ID**: 1a64852d-e958-49b1-aac2-84ac2c2b1aed
**Framework**: chatdev
**Started**: 2025-10-31T00:51:11.673919Z
**Completed**: 2025-10-31T01:12:22.699104Z
**Duration**: 1271.03s
**Total Sprints**: 6

## Sprint Results

| Sprint | Step ID | Status | Tokens (in/out) | API Calls | Time (s) |
|--------|---------|--------|-----------------|-----------|----------|
| 1 | 1 | completed | 0/0 | 0 | 222.60 |
| 2 | 2 | completed | 0/0 | 0 | 219.10 |
| 3 | 3 | completed | 0/0 | 0 | 179.41 |
| 4 | 4 | completed | 0/0 | 0 | 225.97 |
| 5 | 5 | completed | 0/0 | 0 | 206.82 |
| 6 | 6 | completed | 0/0 | 0 | 217.11 |

## Directory Structure

```
1a64852d-e958-49b1-aac2-84ac2c2b1aed/
├── sprint_001/          # First sprint artifacts
│   ├── generated_artifacts/
│   ├── logs/
│   ├── metadata.json
│   └── validation.json
├── sprint_002/          # Second sprint artifacts
│   └── ...
├── final/               # Symlink to last successful sprint
└── metrics.json         # Run-level metrics (single source of truth)
```

## Accessing Results

### View final artifacts
```bash
cd final/generated_artifacts/managed_system/
```

### Compare sprints
```bash
diff -r sprint_001/generated_artifacts sprint_002/generated_artifacts
```

### View metrics (single source of truth)
```bash
cat metrics.json | jq
```

### Check specific sprint
```bash
cat sprint_001/metadata.json
```
