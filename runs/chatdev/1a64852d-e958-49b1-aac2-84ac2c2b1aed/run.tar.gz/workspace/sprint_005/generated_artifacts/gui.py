'''
Graphical User Interface for managing courses and teachers.
'''
# This file is not modified as per the task requirements.