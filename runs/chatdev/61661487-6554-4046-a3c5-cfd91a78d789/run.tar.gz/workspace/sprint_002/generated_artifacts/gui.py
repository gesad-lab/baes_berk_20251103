'''
Main GUI for the student application.
'''
# GUI code would go here, if applicable.