'''
Runs the FastAPI application using Uvicorn.
'''
uvicorn main:app --reload