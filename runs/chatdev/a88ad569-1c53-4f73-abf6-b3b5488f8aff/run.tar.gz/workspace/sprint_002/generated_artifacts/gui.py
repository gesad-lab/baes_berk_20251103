'''
This file contains the graphical user interface for the Student Management system.
'''
# (No changes made in this file)