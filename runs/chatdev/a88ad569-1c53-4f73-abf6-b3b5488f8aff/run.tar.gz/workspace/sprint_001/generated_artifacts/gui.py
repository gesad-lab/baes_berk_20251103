/student_app
    ├── main.py
    ├── models.py
    ├── schemas.py
    ├── database.py
    └── gui.py