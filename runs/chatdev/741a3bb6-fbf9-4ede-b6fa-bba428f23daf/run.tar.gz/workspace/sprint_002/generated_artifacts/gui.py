'''
Handles the graphical user interface for the student application.
'''
# No changes needed in gui.py for this task.