/student_app
    ├── main.py
    ├── models.py
    ├── database.py
    ├── schemas.py
    ├── crud.py
    └── gui.py