'''
Graphical User Interface for the Student application.
'''
# Code for GUI will be added here as needed.