/student_app
    ├── main.py
    ├── models.py
    ├── schemas.py
    ├── database.py
    ├── routes.py
    └── gui.py