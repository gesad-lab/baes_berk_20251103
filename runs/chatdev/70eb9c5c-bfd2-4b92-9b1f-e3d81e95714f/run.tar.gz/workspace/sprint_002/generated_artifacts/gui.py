'''
Main GUI for the Student application.
'''
# GUI code goes here (not provided in the original code)