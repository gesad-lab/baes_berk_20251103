'''
Main entry point for the application.
'''
# No changes needed in main.py as it is already structured correctly.