'''
Graphical User Interface for the Student application.
'''
# No changes needed in gui.py as it is already structured correctly.