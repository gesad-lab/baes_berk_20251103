'''
Database migration command to apply the latest changes.
'''
alembic upgrade head