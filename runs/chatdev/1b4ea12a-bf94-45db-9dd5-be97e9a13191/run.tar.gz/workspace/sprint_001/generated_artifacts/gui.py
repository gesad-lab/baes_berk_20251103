/student_app
    ├── main.py
    ├── models.py
    ├── database.py
    ├── schemas.py
    └── gui.py