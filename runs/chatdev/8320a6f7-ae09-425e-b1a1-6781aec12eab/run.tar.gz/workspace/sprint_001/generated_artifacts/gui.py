chatdev_app/
│
├── main.py
├── models.py
├── database.py
├── routes.py
└── gui.py