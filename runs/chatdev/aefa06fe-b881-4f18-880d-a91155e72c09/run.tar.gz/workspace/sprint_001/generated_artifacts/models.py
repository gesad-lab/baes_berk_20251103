'''
Defines the SQLAlchemy model for the Student entity.
'''
from sqlalchemy import Column, Integer, String
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from database import SessionLocal
Base = declarative_base()
class Student(Base):
    __tablename__ = "students"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    def save(self):
        try:
            db = SessionLocal()
            db.add(self)
            db.commit()
            db.refresh(self)
        except Exception as e:
            db.rollback()
            raise e
        finally:
            db.close()
    @classmethod
    def get(cls, student_id):
        try:
            db = SessionLocal()
            student = db.query(cls).filter(cls.id == student_id).first()
            return student
        except Exception as e:
            raise e
        finally:
            db.close()