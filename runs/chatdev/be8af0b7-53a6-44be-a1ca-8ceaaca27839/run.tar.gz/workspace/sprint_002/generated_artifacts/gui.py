'''
Main GUI file for the student application.
'''
# This file is currently empty, but you can add GUI code here as needed.