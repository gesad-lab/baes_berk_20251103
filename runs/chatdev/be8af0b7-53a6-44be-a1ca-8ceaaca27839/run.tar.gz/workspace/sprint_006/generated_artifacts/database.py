'''
Handles database connection and session management.
'''
from sqlalchemy import create_engine, Column, String, Integer, ForeignKey, inspect  # Import the inspect function
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, Session
DATABASE_URL = "sqlite:///./students.db"
engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()
def create_database():
    '''
    Creates the database and tables if they do not exist.
    '''
    Base.metadata.create_all(bind=engine)
def migrate_database():
    '''
    Migrates the database to add the Teacher table and ensure existing data is preserved.
    '''
    inspector = inspect(engine)  # Create an inspector object
    # Check if the teachers table exists before creating it
    if not inspector.has_table('teachers'):
        Base.metadata.create_all(bind=engine)  # This will create the teachers table if it does not exist
    # Check if the teacher_id column exists in the courses table
    columns = [column['name'] for column in inspector.get_columns('courses')]
    if 'teacher_id' not in columns:
        with engine.connect() as connection:
            connection.execute('ALTER TABLE courses ADD COLUMN teacher_id INTEGER REFERENCES teachers(id);')
def get_db() -> Session:
    '''
    Dependency that provides a database session.
    '''
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()