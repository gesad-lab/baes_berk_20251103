'''
This file contains the GUI implementation for the Student application.
'''
# GUI code would be implemented here