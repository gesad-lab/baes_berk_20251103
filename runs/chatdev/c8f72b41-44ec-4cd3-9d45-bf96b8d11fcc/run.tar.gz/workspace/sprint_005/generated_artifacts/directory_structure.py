/student_app
    ├── main.py
    ├── models.py
    ├── database.py
    ├── api.py
    └── alembic.ini