'''
Main GUI application for managing students, courses, and teachers.
'''
/student_app
    ├── main.py
    ├── models.py
    ├── database.py
    ├── routes.py
    └── gui.py