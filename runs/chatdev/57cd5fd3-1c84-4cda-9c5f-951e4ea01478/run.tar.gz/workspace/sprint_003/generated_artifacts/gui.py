'''
Main GUI file for the Student application.
'''
# GUI code would go here (not provided in the original code)