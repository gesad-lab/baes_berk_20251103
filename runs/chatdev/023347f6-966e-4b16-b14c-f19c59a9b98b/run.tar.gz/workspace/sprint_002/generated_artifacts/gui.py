'''
Main GUI file for the student application.
'''
# GUI implementation code would go here