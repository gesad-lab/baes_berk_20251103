'''
Main GUI file for the student application.
'''
# This file is currently empty. You can implement the GUI logic here.