'''
Main GUI file for the student and course application.
'''
# This file is currently empty. You can implement the GUI logic here.