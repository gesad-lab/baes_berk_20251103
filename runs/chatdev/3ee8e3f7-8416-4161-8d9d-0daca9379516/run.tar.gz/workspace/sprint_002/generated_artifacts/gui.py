'''
Main entry point for the Student application.
'''
/student_app
    ├── main.py
    ├── models.py
    ├── database.py
    ├── schemas.py
    └── routers.py