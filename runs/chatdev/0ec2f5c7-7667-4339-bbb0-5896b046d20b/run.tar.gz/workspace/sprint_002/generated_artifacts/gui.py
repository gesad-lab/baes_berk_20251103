'''
Graphical User Interface for the ChatDev Student Application.
'''
# (No changes made to this file as it was not specified in the task)