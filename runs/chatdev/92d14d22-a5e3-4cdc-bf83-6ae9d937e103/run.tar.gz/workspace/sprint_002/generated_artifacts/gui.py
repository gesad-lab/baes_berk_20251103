'''
Main GUI file for the Student application.
'''
# GUI code would go here (if applicable)