chatdev_student_app/
│
├── main.py
├── models.py
├── database.py
├── schemas.py
├── routes.py
└── gui.py