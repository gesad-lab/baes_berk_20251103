'''
Command to run the FastAPI application using Uvicorn.
'''
uvicorn main:app --reload