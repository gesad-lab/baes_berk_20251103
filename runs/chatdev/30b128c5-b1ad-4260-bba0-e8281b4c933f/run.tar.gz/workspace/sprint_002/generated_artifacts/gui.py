'''
Handles the GUI for the Student Management application.
'''
# No changes needed in this file.