/student_app
    ├── main.py
    ├── models.py
    ├── database.py
    ├── api.py
    ├── schemas.py
    └── alembic.ini