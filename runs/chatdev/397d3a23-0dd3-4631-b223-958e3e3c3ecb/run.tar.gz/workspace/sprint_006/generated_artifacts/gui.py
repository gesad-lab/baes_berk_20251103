/student_app
    ├── main.py
    ├── models.py
    ├── database.py
    ├── api.py
    ├── schemas.py
    ├── alembic.ini
    └── migration_create_teacher_table.py