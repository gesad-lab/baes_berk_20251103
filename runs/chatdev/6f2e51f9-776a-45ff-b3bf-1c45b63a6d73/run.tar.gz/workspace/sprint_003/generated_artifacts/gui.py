'''
Main entry point for the application.
'''
/student_app
    ├── main.py
    ├── models.py
    ├── database.py
    ├── routes.py
    └── gui.py