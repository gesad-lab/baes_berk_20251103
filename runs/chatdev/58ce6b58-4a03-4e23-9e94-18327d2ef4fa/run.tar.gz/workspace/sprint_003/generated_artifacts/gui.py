'''
Contains the GUI components for the application.
'''
# GUI code can be implemented here if needed.