'''
Defines the GUI components for the Student and Course Management application.
'''
# Assuming GUI components are defined here...