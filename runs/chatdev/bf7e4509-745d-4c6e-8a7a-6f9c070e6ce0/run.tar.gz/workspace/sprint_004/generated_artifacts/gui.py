'''
Defines the GUI components for the Student and Course Management application.
'''
# Assuming GUI components are defined here...
# Additional GUI components for enrolling students in courses will be added here.