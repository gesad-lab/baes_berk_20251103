'''
Graphical User Interface for the Student Management application.
'''
# This file remains unchanged as it does not require modifications.