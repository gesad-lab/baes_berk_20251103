'''
Main GUI file for the student application.
'''
# This file can be used to implement the GUI logic if needed.