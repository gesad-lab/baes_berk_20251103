/student_app
    ├── main.py
    ├── models.py
    ├── database.py
    ├── routes.py
    └── schemas.py