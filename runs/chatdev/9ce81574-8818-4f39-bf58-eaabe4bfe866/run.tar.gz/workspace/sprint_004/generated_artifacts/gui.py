'''
Directory structure for the student application.
'''
/student_app
    ├── main.py
    ├── models.py
    ├── database.py
    ├── routes.py
    └── schemas.py