'''
This file contains the GUI logic for the student application.
'''
# (Assuming there is GUI code here, which is not provided in the original task)